//Algorithm  for  an Imitation model for Riak system.
function riakStat() {
    var count_of_nodes,
		//count_of_nodes, //count of servers, which are using as storage_nodes.
		//count_of_gateway_nodes,
        key_bucket, //key of needle = 'k' + i + '_' + u,where i,u - integer.
	    n_value, //the datum will replicated to "n_value" separated partitions of the Riak Ring("n_value" copies will be stored at different servers(nodes)).
        w_value,//min number for write copies.
        r_value, //min number for read copies.
        current_needle, //Value of Riak object = [type of Riak object, data size of Riak object in conditional units, input time and context, coefficient  for probability of failure for this type, time size of Riak object in conditional units], type may be: ["text", 0.01, t, 0,1, 0.001], ["foto", 2, t, 1, 0.1], ["vidio", 50, t, 5, 1].
        node_status, //[{key_bucket : "v_clock"}(dictionary for last time of successful write action for Riak objects), {key_bucket:[[name of node, its working_status, time of successful write action or successful repair action for Riak objects]]} (dictionary for list of nodes, where is storing the Riak object with this key),{node: [list of "keys of needles_time", which were storing at node]}, {key_bucket : time of last write action for Riak objects},{key_bucket : indicator of possibility of repair for this needle}( 0 or 1)}].
        list_of_entering_keys,
        total_time_of_finish_performance_actions_at_node,
		
        count_of_data_in_node,
        cluster, //= [[node_i(name(number) of node(server), i - integer),  working_status(1 - working server, 0 - failure), {key_of_needle:Riak_object_value}, count_of_data_in_node, total_time_of_finish_performence_actions_at_node],...].
    //Actions: "write", "read", "send", "storage".
		//gateway_nodes, //=[[gtw_node_i, working_status, total_time_of_finish_performence_actions_at_node],...].
        write_action,
        p_of_write_action, //probability of failure for action, which performs  with a  cond. unit of data.
        use_of_resource_by_write_action, //resource for performing action with	conditional unit of data.
		   
	    read_action,
        p_of_read_action,   //so on ...
        use_of_resource_by_read_action,
	  
	    send_action,
        p_of_send_action,    //so on ...
        use_of_resource_by_send_action,
		use_time_for_performance_send_net_action_with_one_cond_unit_of_data, //in conditional time units.
	    
		p_of_local_failure,//lag of Riak object.
		use_time_for_performance_local_action_with_one_cond_unit_of_data, //in conditional time units.
		count_of_time_for_performance_local_action_with_meta_data, //for service system.
		
		time_for_performance_repair_action,
		
        storage_action,
        p_of_storage_action,
        use_of_resource_by_storage_action,
	   
	    use_of_resource_for_seaching_one_Riak_object_at_one_node,
		
	    total_count_of_data, // in all servers,
	    total_used_resource,
		total_time_of_finish_imitatiion,
        total_use_of_resource_by_write_action,
        total_use_of_resource_by_read_action,
        total_use_of_resource_by_send_action,
	    total_count_of_failures,//net's  partitions,  failures of  equipment.
	    count_of_read_lags,//cases of outdated information.
	    count_of_read_failures,// failures with   requests  for getting data, decreasing of the availability.
		count_of_write_failures,
        count_of_failures_for_write_action,
		count_of_right_write_action,
        count_of_failures_for_send_action,
        count_of_failures_for_read_action,
		count_of_local_failure,
		count_of_right_read_action,
		max_lag_of_performance_of_read_request,
		max_lag_of_performance_for_gateway_nodes,
		//interval_for_repair,
		level_of_intensivity_of_requests,
	    count_of_iterations_for_algorithm;
//Initial setting:
  	write_action = 'write';
    read_action = 'read';
    send_action = 'send';
    p_of_write_action = document.getElementById("fname1").value || 0.01; //("par1").innerHTML; //a probability of  a failure for a write_action, when it is performing with one cond. unit of data.
    use_of_resource_by_write_action = 1; //resource for performing action with one conditional unit of data).
	
    p_of_read_action = document.getElementById("fname4").value || 0.01; //("par4").innerHTML;
	use_of_resource_by_read_action = 1;
	  
    p_of_send_action = document.getElementById("fname3").value || 0.01; //("par3").innerHTML;
	use_of_resource_by_send_action = 3;
	use_time_for_performance_send_net_action_with_one_cond_unit_of_data = 0.1;
	
	p_of_local_failure = document.getElementById("fname11").value || 0.01; //("par11").innerHTML;
	use_time_for_performance_local_action_with_one_cond_unit_of_data = 1; //in conditional time units.
	count_of_time_for_performance_local_action_with_meta_data = 0.21;
	
	time_for_performance_repair_action = 0.5;
	
    p_of_storage_action = 1e-6;
    use_of_resource_by_storage_action = 0.001;

    use_of_resource_for_seaching_one_Riak_object_at_one_node = 0.1;
	count_of_nodes = document.getElementById("fname15").value || 50;//("par15").innerHTML; 
    //count_of_nodes = document.getElementById"fname15".value || 50;("par2").innerHTML;
	//count_of_gateway_nodes = count_of_nodes - count_of_nodes;
    n_value = document.getElementById("fname7").value || 3; //("par7").innerHTML;
    w_value = document.getElementById("fname8").value || 2;//("par8").innerHTML;
    r_value = document.getElementById("fname9").value || 2;//("par9").innerHTML;
	total_count_of_data = 0;
    total_used_resource = 0;
    total_use_of_resource_by_read_action = 0;
    total_use_of_resource_by_send_action = 0;
    total_use_of_resource_by_write_action = 0;
	total_use_of_resource_by_repair_action = 0;
    total_count_of_failures = 0;
	total_time_of_finish_imitatiion = 0;
    count_of_failures_for_write_action = 0;
    count_of_failures_for_send_action = 0;
    count_of_failures_for_read_action = 0;
    count_of_read_lags = 0;
	count_of_local_failure = 0;
    count_of_read_failures = 0;
    count_of_write_failures = 0;
	count_of_right_read_action = 0;
	count_of_right_write_action = 0;
	count_of_wrong_read_request = 0;
	max_lag_of_performance_of_read_request = 0;
	max_lag_of_performance_for_gateway_nodes = 0;
	level_of_intensivity_of_requests = document.getElementById("fname12").value || 20;("par12").innerHTML;
    count_of_iterations_for_algorithm = document.getElementById("fname5").value || 100;("par5").innerHTML;
    interval_for_repair = document.getElementById("fname10").value || 25; //("par10").innerHTML;
    list_of_entering_keys = ['start'];
    gossip_protocol = [{}, {start:[['start', 0, 0], ['node_1', 1, 0], ['node_2', 1, 0], ['node_3', 1, 0]]}, {}, {}, {}]; 
    cluster = [];
	//gateway_nodes = [];
    var k, n;
    for (k = 1; k <=  count_of_nodes; k++) {
        cluster.push(['node_' + k, 1, {}, 0, {}, 0]);
        gossip_protocol[2]['node_' + k] = [];
    }
	// for (n = 1; n <=  count_of_gateway_nodes; n++) {
    //    gateway_nodes.push(['gtw_node_' + n, 1, 0]);
	//}

    function randomElection(objects, probabilities) { //Elects  one of Objects: - objects[i] with a Probability: - probabilities[i], 0 <= i < objects.length, objects.length == probabilities.length.
        var a, b, c;
        a = 0;
        b = 0;
        c = Math.random();
        for (i = 0; i < probabilities.length; i = i + 1) {
            b = a + probabilities[i];
            if (a <= c &&  c < b) {
                return objects[i];
            } else {
                a = b;
            }
        }
    }
              
    function randomElectAndDeleteItem(name_of_array) {
        var index_of_item =  Math.floor(name_of_array.length * Math.random());
        return  name_of_array.splice(index_of_item, 1);//, name_of_array]; // [item, array after deleting].
    }
    
    function uniformDistrOf_n_Elem(n) { //uniform distribution of n elememnts.
        var uniform_distr_of_n_elem = [];//uniform distribution of n elememnts.
        
        for (i = 0; i < n; i = i + 1) {
            uniform_distr_of_n_elem.push(1 / n);
        }
        return uniform_distr_of_n_elem;
    }
    //var elect_of_event_with_probability_p; //value: True, False.
    function electOfEventWithProbability_p(p) { //Test: Was  an event, which has probability p?
        return randomElection([true, false], [p, 1 - p]);
    }

//Steps of algorithm:

    var current_node,
        obj_current,
        current_needle;
    var t, m; //ts - time in nodes
    t = 0;
	
    obj_current = {'start':['empty', 0, 0]};
    m = 0;
    var w, v, u;
    w = 1;
	v = 0;
	
    while (t < count_of_iterations_for_algorithm) { //do
        t = t + 1;
		
		u = 0;
        		var l, a ;
        if (t % interval_for_repair == interval_for_repair - 1) {
		            
					for (x in gossip_protocol[1]) {
				if (gossip_protocol[4][x]) {
					count_of_write_failures  = count_of_write_failures - 1;
					l = 0;
					 while (l < w_value) {
                   	m = (m + 1) % count_of_nodes;
					cluster[m][5] = Math.max(cluster[m][5], t) + time_for_performance_repair_action;//time performance repair.
					total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion, cluster[m][5]);
					gossip_protocol[1][x].push([cluster[m][0] , 1, gossip_protocol[4][x], "repair" + t]);
 		total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action +  obj_current[x][1] * use_of_resource_by_send_action;
                   l = l +1;
					}
					gossip_protocol[4][x] = 0;
					v = v + 1;
					}
                 total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action + use_of_resource_for_seaching_one_Riak_object_at_one_node * (gossip_protocol[1][x].length - 1);
			}	 
            }
			/*var b;
			var pass_gossip_protocol;
            for (x in gossip_protocol[1]) {
                l = 0;
                a = gossip_protocol[1][x].length;
                if (a > 1) {
               while (l <= n_value - a) {
                   	m = (m + 1) % count_of_nodes;
					cluster[m][5] = Math.max(cluster[m][5], t) + time_for_performance_repair_action;//time performance repair.
					total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion, cluster[m][5]);
					gossip_protocol[1][x].push(cluster[m]);
 		total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action +  obj_current[x][1] * use_of_resource_by_send_action;
                   l = l +1;
					}
					b = 0;
				   pass_gossip_protocol = [];
				for (j = 0; j <  gossip_protocol[1][x].length; j++) {
                    if ( (gossip_protocol[1][x][j] != []) && (gossip_protocol[1][x][j] != undefined )) {
                        if ((gossip_protocol[1][x][j][1] == 0) && (gossip_protocol[1][x][j][0] != 'start')) {
						for (n = 0; n < cluster.length; n++) {
							if (cluster[n][0] == gossip_protocol[1][x][j][0]) {
									cluster[n][1] = 1;
									}
								}		
								
						          total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action + use_of_resource_for_seaching_one_Riak_object_at_one_node * (gossip_protocol[1][x].length - 1);   
							gossip_protocol[1][x][j][1] = 1;
							gossip_protocol[1][x][j][2] = t;
							}
							if ((gossip_protocol[1][x][j][0] != 'start') && (b < n_value)) {
								pass_gossip_protocol.push(gossip_protocol[1][x][j]);
								b = b + 1;
                    }
                    }    
                        
                    }
					gossip_protocol[1][x] = [['start', 0, 0]];
					for (i = 0; i < pass_gossip_protocol.length; i++) {
						gossip_protocol[1][x].push(pass_gossip_protocol[i]);
						}
                }
            }*/
				for (n = 0; n < cluster.length; n++) {
						cluster[n][1] = 1;
				}			
            //}
        while (u < level_of_intensivity_of_requests) {
		u = u + 1;
		var curr_nod, gtw_curr_nod, change_gossip_protocol;
			/*gtw_curr_nod = randomElectAndDeleteItem(gateway_nodes);//Gateway operation with write request(begin).
			//console.log(gtw_curr_nod[0], t, gtw_curr_nod[0][2],'ww');
			gtw_curr_nod[0][2] = Math.max(gtw_curr_nod[0][2], t) + count_of_time_for_performance_local_action_with_meta_data;
			//console.log(gtw_curr_nod[0], t, gtw_curr_nod[0][2],'w');
			max_lag_of_performance_for_gateway_nodes = gtw_curr_nod[0][2] - t;
			gateway_nodes.push(gtw_curr_nod[0]); //Gateway operation with write request(finish).*/
         var current_action;
         current_action = randomElection([write_action, read_action], [0.3, 0.7]); //random election of action.
    
        if (current_action === write_action) {//then do a realisation of  the action.
            w = w +1;
            if (electOfEventWithProbability_p(0.6)) {
               
                 list_of_entering_keys.push('k' + t + '_' + u);
            key_of_needle = 'k' + t + '_' + u;
                // console.log(key_of_needle, 'con2a')
                gossip_protocol[1][key_of_needle] = [['start', 0, 0]];
				} else {
            var u2 = list_of_entering_keys.length;
            u2 = list_of_entering_keys.length;
            key_of_needle = randomElection(list_of_entering_keys,  uniformDistrOf_n_Elem(u));
		}
                   
            current_needle =  randomElection([["text", 0.01, t, 0.1, 0.001], ["foto", 2, t, 1, 0.1], ["vidio", 50, t, 5, 1]], [0.2, 0.7, 0.1]); // random election of Raik object, which is coming.
            obj_current[key_of_needle] = current_needle;
            gossip_protocol[3][key_of_needle] = t;
            gossip_protocol[4][key_of_needle] = 0;
			
            var c = n_value;  //counter,shows count of nodes,wich must contain new Raik object
            c = n_value;
			
			change_gossip_protocol = [['start', 0, 0]];
            var j = 0;
			var r, s;
            curr_ar = [];
            s = 0;
		    r = 0;
            j = 0;
            while (j < n_value) {
                j = j + 1;
                curr_nod = randomElectAndDeleteItem(cluster);
				if(curr_nod[0]) {
					curr_ar.push(curr_nod[0]);
                var g = randomElection([1, 0], [1 - p_of_write_action * current_needle[3], p_of_write_action * current_needle[3]]);
                var d = randomElection([1, 0], [1 - p_of_send_action * current_needle[3], p_of_send_action * current_needle[3]]);
                if (curr_nod[0][1]) {
					if (d) {
                        if (g) { //write_action finished right.
							if (randomElection([1, 0], [1 - p_of_local_failure * current_needle[3], p_of_local_failure * current_needle[3]])) {
                            curr_nod[0][2][key_of_needle] = t //current_needle, put new Riak objeckt, or fresh information with same key value.
			                curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
							curr_nod[0][5] = Math.max(curr_nod[0][5], t) + use_time_for_performance_local_action_with_one_cond_unit_of_data * current_needle[4];//time for performance local action.
							total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion,curr_nod[0][5]);	
							change_gossip_protocol.push([curr_nod[0][0], 1, t]);//succesful write action for node.
                            gossip_protocol[2][curr_nod[0][0]].push(key_of_needle + '_' + t);
                            total_count_of_data  = total_count_of_data + current_needle[1]; //fresh information
			                total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
							if(gossip_protocol[1][key_of_needle]) {
								gossip_protocol[1][key_of_needle].push([curr_nod[0][0], 0, t]);
								}
							r = r + 1; 
							} else {
								r = r + 1;
								if(gossip_protocol[1][key_of_needle]) {
								gossip_protocol[1][key_of_needle].push([curr_nod[0][0], 0, t]);
								}
								curr_nod[0][2][key_of_needle] = t //current_needle, put new Riak objeckt
								curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
								c = c - 1;
								total_count_of_failures = total_count_of_failures + 1; //fresh information.
								total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
								total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
								total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
								count_of_local_failure = count_of_local_failure +1;
								}
			            } else {
							r = r + 1;
			                curr_nod[0][1] = 0; // set 0 for the work_status node_j.
							if(gossip_protocol[1][key_of_needle]) {
							gossip_protocol[1][key_of_needle].push([curr_nod[0][0], 0, t]);
							}
                            curr_nod[0][2][key_of_needle] = t //current_needle, put new Riak objeckt
			                curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
			                c = c - 1;
			                total_count_of_failures = total_count_of_failures + 1; //fresh information.
                            count_of_failures_for_write_action = count_of_failures_for_write_action + 1;
                            total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                        }
                    } else {
		                c = c - 1;
			            total_count_of_failures = total_count_of_failures + 1; //fresh information.
                        count_of_failures_for_send_action = count_of_failures_for_send_action + 1;
				        total_used_resource = total_used_resource + use_of_resource_by_send_action * current_needle[1];
                        total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                    }
                } else {
		            c = c - 1;
                }  
    } else {
	     c = c - 1;
		 }
	}
            for (k = 0; k < curr_ar.length; k++) {
        cluster.push(curr_ar[k]);
            }
              if (c < w_value ) {
                count_of_write_failures = count_of_write_failures + 1;				 // loss of availability.
				if (r) {
				gossip_protocol[4][key_of_needle] = t; 
				}
            } else {
				gossip_protocol[1][key_of_needle] = change_gossip_protocol;
                count_of_right_write_action = count_of_right_write_action + 1;
                gossip_protocol[0][key_of_needle] = t;
               }             
			
        }
        //else {
        var u1;
        if (current_action === read_action) {
            if (w) {
           u1 = list_of_entering_keys.length;
            key_of_needle = randomElection(list_of_entering_keys,  uniformDistrOf_n_Elem(u));
			
            current_needle = obj_current[key_of_needle];
           
            var b1, c1;  //counter,shows count of nodes,which must contain new Raik object
            c1 = 0;
			           
            var gossip_protocol_read;
            gossip_protocol_read = [];    
            var curr_nod1, gtw_curr_nod1, g1, d1, t0, j1, q;
				
                q = 0;
                t0 = 0;
                j1 = 0;
                if ((gossip_protocol[1][key_of_needle] != []) && (gossip_protocol[1][key_of_needle] != undefined)) {
				b1 = gossip_protocol[1][key_of_needle].length;
            while (j1 < b1) {
                j1 = j1 + 1;
                 
                curr_nod1 = randomElectAndDeleteItem(gossip_protocol[1][key_of_needle]);
                gossip_protocol_read.push(curr_nod1[0]);
				if (curr_nod1[0]) {
				                
                g1 = randomElection([1, 0], [1 - p_of_read_action * current_needle[3], p_of_read_action * current_needle[3]]);
                d1 = randomElection([1, 0], [1 - p_of_send_action * current_needle[3], p_of_send_action * current_needle[3]]);
            
                if (curr_nod1[0][1]) {
                    if (d1) {
                        if (g1) { //read_action finished right.
						    if(curr_nod1[0][2] > t0) {
							t0 = curr_nod1[0][2];
							}
							for (n = 0; n < cluster.length; n++) {
							if (cluster[n][0] == curr_nod1[0][0]) {
                            cluster[n][5] = Math.max(cluster[n][5],  t) +  use_time_for_performance_local_action_with_one_cond_unit_of_data * current_needle[4];//time for performance local action.
							max_lag_of_performance_of_read_request = Math.max(max_lag_of_performance_of_read_request, cluster[n][5] - t);
							total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion,cluster[n][5]);
							}
							}
			                total_used_resource = total_used_resource + (use_of_resource_by_read_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_read_action = total_use_of_resource_by_read_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
							c1 = c1 +1;
			            } else {

			                total_count_of_failures = total_count_of_failures + 1; //fresh information.
                            count_of_failures_for_read_action = count_of_failures_for_read_action + 1;
                            total_used_resource = total_used_resource + (use_of_resource_by_read_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_read_action = total_use_of_resource_by_read_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                        }
                    } else {
		                //c1 = c1 - 1;
                       
			            total_count_of_failures = total_count_of_failures + 1; //fresh information.
                        count_of_failures_for_send_action = count_of_failures_for_send_action + 1;
				        total_used_resource = total_used_resource + use_of_resource_by_send_action * current_needle[1];
                        total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
						
                    }
                }
				} else {
						q = q + 1;
						}
		}			
   } else {
				count_of_wrong_read_request = count_of_wrong_read_request + 1;
				}				
      for(i = 0; i < gossip_protocol_read.length; i++) {
          if (gossip_protocol_read[i] != undefined) {                 
       gossip_protocol[1][key_of_needle].push(gossip_protocol_read[i]);
	   }
     }
	 gossip_protocol_read = [];
		if (q > 2) {
					count_of_wrong_read_request = count_of_wrong_read_request + 1;
					}
         if (c1 < r_value ) {
                
                count_of_read_failures = count_of_read_failures + 1;// loss of availability.
            } else {
                count_of_right_read_action = count_of_right_read_action + 1;
                if (gossip_protocol[3][key_of_needle] > t0) {
				count_of_read_lags = count_of_read_lags +1; //cases of outdate information.
				}
				}
}				
}				
        }  
        }    
	total_used_resource = total_used_resource + total_use_of_resource_by_repair_action;
   /*console.log('count_of_right_read_action - ' + count_of_right_read_action,
			'count_of_right_write_action - ' + count_of_right_write_action,
			'count_of_failures_for_send_action - ' + count_of_failures_for_send_action, 'count_of_failures_for_write_action - ' + count_of_failures_for_write_action, 'count_of_failures_for_read_action - ' + count_of_failures_for_read_action,
			'count_of_local_failure - ' + count_of_local_failure,
			'count_of_wrong_read_request - ' + count_of_wrong_read_request,
			'total_use_of_resource_by_write_action - ' + Math.floor(total_use_of_resource_by_write_action), 'total_use_of_resource_by_read_action - ' + Math.floor(total_use_of_resource_by_read_action), 'total_use_of_resource_by_send_action - ' + Math.floor(total_use_of_resource_by_send_action),
			'total_time_of_finish_imitatiion - ' + total_time_of_finish_imitatiion,
    		'total_use_of_resource_by_repair_action - ' + Math.floor(total_use_of_resource_by_repair_action));

//output of algorithm:

   alert(["total_count_of_data - " + Math.floor(total_count_of_data), // in all servers,
	    "total_used_resource - " + Math.floor(total_used_resource),
	    "total_count_of_failures - " + total_count_of_failures,//net's  partitions,  failures of  equipment.
	    "count_of_read_lags(outdated information) - " + count_of_read_lags,//cases of outdate information.
	    "count_of_read_failures (decreasing of the availability) - " + count_of_read_failures,// failures to   requests  for getting data.
	    "count_of_write_failures (decreasing of the availability) - " + count_of_write_failures,
		"max_lag_of_performance_of_read_request - " + max_lag_of_performance_of_read_request.toFixed(3),
		"max_lag_of_performance_for_gateway_nodes - " + max_lag_of_performance_for_gateway_nodes.toFixed(3),
	    "count_of_read//write_actions - " + count_of_iterations_for_algorithm * level_of_intensivity_of_requests]);
     console.log(gossip_protocol, 'con_gp_f',total_count_of_data / total_used_resource , (count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests), ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests) - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests), w, v,cluster);
   
return [(total_count_of_data / total_used_resource).toFixed(3) + '  ', ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)).toFixed(3) + '  ',  ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)).toFixed(3) + '  ', total_count_of_data.toPrecision(4) + '  ', total_used_resource.toPrecision(4) + '  ',count_of_read_lags, count_of_read_failures, count_of_write_failures, Math.round(max_lag_of_performance_of_read_request), count_of_iterations_for_algorithm * level_of_intensivity_of_requests, w]*/ 
return [(total_count_of_data / total_used_resource).toFixed(3), (((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)) * 100).toFixed(3),  (((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)) * 100).toFixed(3), total_count_of_data.toPrecision(4), total_used_resource.toPrecision(4), total_count_of_failures, count_of_read_lags, count_of_read_failures, count_of_write_failures, max_lag_of_performance_of_read_request.toFixed(3), count_of_iterations_for_algorithm * level_of_intensivity_of_requests, w]    
}

//Algorithm  for  an Imitation model for Leofs system.
function leoStat() {
    var count_of_nodes,
		count_of_storage_nodes, //count of servers, which are using as storage_nodes.
		count_of_gateway_nodes,
        key_needle, //key of needle = 'k' + i + '_' + u,where i,u - integer.
	    n_value, //the datum will replicated to "n_value" separated partitions of the Leofs Ring("n_value" copies will be stored at different servers(nodes)).
        w_value,//min number for write copies.
        r_value, //min number for read copies.
        current_needle, //Value of Leofs object = [type of Leofs object, data size of Leofs object in conditional units, input time and context, coefficient  for probability of failure for this type, time size of Leofs object in conditional units], type may be: ["text", 0.01, t, 0,1, 0.001], ["foto", 2, t, 1, 0.1], ["vidio", 50, t, 5, 1].
        node_status, //[{key_needle : "v_clock"}(dictionary for last time of successful write action for Leofs objects), {key_needle:[[name of node, its working_status, time of successful write action or successful repair action for Leofs objects]]} (dictionary for list of nodes, where is storing the Leofs object with this key),{node: [list of "keys of needles_time", which were storing at node]}, {key_needle : time of last write action for Leofs objects},{key_needle : indicator of possibility of repair for this needle}( 0 or 1)}].
        list_of_entering_keys,
        total_time_of_finish_performance_actions_at_node,
		
        count_of_data_in_node,
        storage_nodes, //= [[node_i(name(number) of node(server), i - integer),  working_status(1 - working server, 0 - failure), {key_of_needle:Leofs_object_value}, count_of_data_in_node, total_time_of_finish_performence_actions_at_node],...].
    //Actions: "write", "read", "send", "storage".
		gateway_nodes, //=[[gtw_node_i, working_status, total_time_of_finish_performence_actions_at_node],...].
        write_action,
        p_of_write_action, //probability of failure for action, which performs  with a  cond. unit of data.
        use_of_resource_by_write_action, //resource for performing action with	conditional unit of data.
		   
	    read_action,
        p_of_read_action,   //so on ...
        use_of_resource_by_read_action,
	  
	    send_action,
        p_of_send_action,    //so on ...
        use_of_resource_by_send_action,
		use_time_for_performance_send_net_action_with_one_cond_unit_of_data, //in conditional time units.
	    
		p_of_local_failure,//lag of Leofs object.
		use_time_for_performance_local_action_with_one_cond_unit_of_data, //in conditional time units.
		count_of_time_for_performance_local_action_with_meta_data, //for service system.
		
		time_for_performance_repair_action,
		
        storage_action,
        p_of_storage_action,
        use_of_resource_by_storage_action,
	   
	    use_of_resource_for_seaching_one_Leofs_object_at_one_node,
		
	    total_count_of_data, // in all servers,
	    total_used_resource,
		total_time_of_finish_imitatiion,
        total_use_of_resource_by_write_action,
        total_use_of_resource_by_read_action,
        total_use_of_resource_by_send_action,
	    total_count_of_failures,//net's  partitions,  failures of  equipment.
	    count_of_read_lags,//cases of outdated information.
	    count_of_read_failures,// failures with   requests  for getting data, decreasing of the availability.
		count_of_write_failures,
        count_of_failures_for_write_action,
		count_of_right_write_action,
        count_of_failures_for_send_action,
        count_of_failures_for_read_action,
		count_of_local_failure,
		count_of_right_read_action,
		max_lag_of_performance_of_read_request,
		max_lag_of_performance_for_gateway_nodes,
		//interval_for_repair,
		level_of_intensivity_of_requests,
	    count_of_iterations_for_algorithm;
//Initial setting:
  	write_action = 'write';
    read_action = 'read';
    send_action = 'send';
    p_of_write_action = document.getElementById("fname1").value || 0.01; //("par1").innerHTML; //a probability of  a failure for a write_action, when it is performing with one cond. unit of data.
    use_of_resource_by_write_action = 1; //resource for performing action with one conditional unit of data).
	
    p_of_read_action = document.getElementById("fname4").value || 0.01; //("par4").innerHTML;
	use_of_resource_by_read_action = 1;
	  
    p_of_send_action = document.getElementById("fname3").value || 0.01; //("par3").innerHTML;
	use_of_resource_by_send_action = 3;
	use_time_for_performance_send_net_action_with_one_cond_unit_of_data = 0.1;
	
	p_of_local_failure = document.getElementById("fname11").value || 0.01; //("par11").innerHTML;
	use_time_for_performance_local_action_with_one_cond_unit_of_data = 1; //in conditional time units.
	count_of_time_for_performance_local_action_with_meta_data = 0.21;
	
	time_for_performance_repair_action = 0.5;
	
    p_of_storage_action = 1e-6;
    use_of_resource_by_storage_action = 0.001;

    use_of_resource_for_seaching_one_Leofs_object_at_one_node = 0.1;
	count_of_nodes = document.getElementById("fname15").value || 50; //("par15").innerHTML; 
    count_of_storage_nodes = document.getElementById("fname2").value || 40; //("par2").innerHTML;
	count_of_gateway_nodes = count_of_nodes - count_of_storage_nodes;
    n_value = document.getElementById("fname7").value || 3; //("par7").innerHTML;
    w_value = document.getElementById("fname8").value || 2; //("par8").innerHTML;
    r_value = document.getElementById("fname9").value || 2; //("par9").innerHTML;
	total_count_of_data = 0;
    total_used_resource = 0;
    total_use_of_resource_by_read_action = 0;
    total_use_of_resource_by_send_action = 0;
    total_use_of_resource_by_write_action = 0;
	total_use_of_resource_by_repair_action = 0;
    total_count_of_failures = 0;
	total_time_of_finish_imitatiion = 0;
    count_of_failures_for_write_action = 0;
    count_of_failures_for_send_action = 0;
    count_of_failures_for_read_action = 0;
    count_of_read_lags = 0;
	count_of_local_failure = 0;
    count_of_read_failures = 0;
    count_of_write_failures = 0;
	count_of_right_read_action = 0;
	count_of_right_write_action = 0;
	count_of_wrong_read_request = 0;
	max_lag_of_performance_of_read_request = 0;
	max_lag_of_performance_for_gateway_nodes = 0;
	level_of_intensivity_of_requests = document.getElementById("fname12").value || 20;("par12").innerHTML;
    count_of_iterations_for_algorithm = document.getElementById("fname5").value || 100;("par5").innerHTML;
    //interval_for_repair = document.getElementById"fname15".value || 50;("par10").innerHTML;
    list_of_entering_keys = ['start'];
    node_status = [{}, {start:[['start', 0, 0], ['node_1', 1, 0], ['node_2', 1, 0], ['node_3', 1, 0]]}, {}, {}, {}]; 
    storage_nodes = [];
	gateway_nodes = [];
    var k, n;
    for (k = 1; k <=  count_of_storage_nodes; k++) {
        storage_nodes.push(['node_' + k, 1, {}, 0, {}, 0]);
        node_status[2]['node_' + k] = [];
    }
	 for (n = 1; n <=  count_of_gateway_nodes; n++) {
        gateway_nodes.push(['gtw_node_' + n, 1, 0]);
	}

    function randomElection(objects, probabilities) { //Elects  one of Objects: - objects[i] with a Probability: - probabilities[i], 0 <= i < objects.length, objects.length == probabilities.length.
        var a, b, c;
        a = 0;
        b = 0;
        c = Math.random();
        for (i = 0; i < probabilities.length; i = i + 1) {
            b = a + probabilities[i];
            if (a <= c &&  c < b) {
                return objects[i];
            } else {
                a = b;
            }
        }
    }
              
    function randomElectAndDeleteItem(name_of_array) {
        var index_of_item =  Math.floor(name_of_array.length * Math.random());
        return  name_of_array.splice(index_of_item, 1);//, name_of_array]; // [item, array after deleting].
    }
    
    function uniformDistrOf_n_Elem(n) { //uniform distribution of n elememnts.
        var uniform_distr_of_n_elem = [];//uniform distribution of n elememnts.
        
        for (i = 0; i < n; i = i + 1) {
            uniform_distr_of_n_elem.push(1 / n);
        }
        return uniform_distr_of_n_elem;
    }
    //var elect_of_event_with_probability_p; //value: True, False.
    function electOfEventWithProbability_p(p) { //Test: Was  an event, which has probability p?
        return randomElection([true, false], [p, 1 - p]);
    }

//Steps of algorithm:

    var current_node,
        obj_current,
        current_needle;
    var t, m; //ts - time in nodes
    t = 0;
	
    obj_current = {'start':['empty', 0, 0]};
    m = 0;
    var w, v, u;
    w = 1;
	v = 0;
	
    while (t < count_of_iterations_for_algorithm) { //do
        t = t + 1;
		
		u = 0;
        		var l, a ;
        //if (t % interval_for_repair == interval_for_repair - 1) {
		            
					for (x in node_status[1]) {
				if (node_status[4][x]) {
					count_of_write_failures  = count_of_write_failures - 1;
					l = 0;
					 while (l < w_value) {
                   	m = (m + 1) % count_of_storage_nodes;
					storage_nodes[m][5] = Math.max(storage_nodes[m][5], t) + time_for_performance_repair_action;//time performance repair.
					total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion, storage_nodes[m][5]);
					node_status[1][x].push([storage_nodes[m][0] , 1, node_status[4][x], "repair" + t]);
 		total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action +  obj_current[x][1] * use_of_resource_by_send_action;
                   l = l +1;
					}
					node_status[4][x] = 0;
					v = v + 1;
					}
                 total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action + use_of_resource_for_seaching_one_Leofs_object_at_one_node * (node_status[1][x].length - 1);
				 
            }
			/*var b;
			var pass_node_status;
            for (x in node_status[1]) {
                l = 0;
                a = node_status[1][x].length;
                if (a > 1) {
               while (l <= n_value - a) {
                   	m = (m + 1) % count_of_storage_nodes;
					storage_nodes[m][5] = Math.max(storage_nodes[m][5], t) + time_for_performance_repair_action;//time performance repair.
					total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion, storage_nodes[m][5]);
					node_status[1][x].push(storage_nodes[m]);
 		total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action +  obj_current[x][1] * use_of_resource_by_send_action;
                   l = l +1;
					}
					b = 0;
				   pass_node_status = [];
				for (j = 0; j <  node_status[1][x].length; j++) {
                    if ( (node_status[1][x][j] != []) && (node_status[1][x][j] != undefined )) {
                        if ((node_status[1][x][j][1] == 0) && (node_status[1][x][j][0] != 'start')) {
						for (n = 0; n < storage_nodes.length; n++) {
							if (storage_nodes[n][0] == node_status[1][x][j][0]) {
									storage_nodes[n][1] = 1;
									}
								}		
								
						          total_use_of_resource_by_repair_action = total_use_of_resource_by_repair_action + use_of_resource_for_seaching_one_Leofs_object_at_one_node * (node_status[1][x].length - 1);   
							node_status[1][x][j][1] = 1;
							node_status[1][x][j][2] = t;
							}
							if ((node_status[1][x][j][0] != 'start') && (b < n_value)) {
								pass_node_status.push(node_status[1][x][j]);
								b = b + 1;
                    }
                    }    
                        
                    }
					node_status[1][x] = [['start', 0, 0]];
					for (i = 0; i < pass_node_status.length; i++) {
						node_status[1][x].push(pass_node_status[i]);
						}
                }
            }*/
				for (n = 0; n < storage_nodes.length; n++) {
						storage_nodes[n][1] = 1;
				}			
            //}
        while (u < level_of_intensivity_of_requests) {
		u = u + 1;
		var curr_nod, gtw_curr_nod, change_node_status;
			gtw_curr_nod = randomElectAndDeleteItem(gateway_nodes);//Gateway operation with write request(begin).
			//console.log(gtw_curr_nod[0], t, gtw_curr_nod[0][2],'ww');
			gtw_curr_nod[0][2] = Math.max(gtw_curr_nod[0][2], t) + count_of_time_for_performance_local_action_with_meta_data;
			//console.log(gtw_curr_nod[0], t, gtw_curr_nod[0][2],'w');
			max_lag_of_performance_for_gateway_nodes = gtw_curr_nod[0][2] - t;
			gateway_nodes.push(gtw_curr_nod[0]); //Gateway operation with write request(finish).
         var current_action;
         current_action = randomElection([write_action, read_action], [0.3, 0.7]); //random election of action.
    
        if (current_action === write_action) {//then do a realisation of  the action.
            w = w +1;
            if (electOfEventWithProbability_p(0.6)) {
               
                 list_of_entering_keys.push('k' + t + '_' + u);
            key_of_needle = 'k' + t + '_' + u;
                // console.log(key_of_needle, 'con2a')
                node_status[1][key_of_needle] = [['start', 0, 0]];
				} else {
            var u2 = list_of_entering_keys.length;
            u2 = list_of_entering_keys.length;
            key_of_needle = randomElection(list_of_entering_keys,  uniformDistrOf_n_Elem(u));
		}
                   
            current_needle =  randomElection([["text", 0.01, t, 0.1, 0.001], ["foto", 2, t, 1, 0.1], ["vidio", 50, t, 5, 1]], [0.2, 0.7, 0.1]); // random election of Raik object, which is coming.
            obj_current[key_of_needle] = current_needle;
            node_status[3][key_of_needle] = t;
            node_status[4][key_of_needle] = 0;
			
            var c = n_value;  //counter,shows count of nodes,wich must contain new Raik object
            c = n_value;
			
			change_node_status = [['start', 0, 0]];
            var j = 0;
			var r, s;
            curr_ar = [];
            s = 0;
		    r = 0;
            j = 0;
            while (j < n_value) {
                j = j + 1;
                curr_nod = randomElectAndDeleteItem(storage_nodes);
				if(curr_nod[0]) {
					curr_ar.push(curr_nod[0]);
                var g = randomElection([1, 0], [1 - p_of_write_action * current_needle[3], p_of_write_action * current_needle[3]]);
                var d = randomElection([1, 0], [1 - p_of_send_action * current_needle[3], p_of_send_action * current_needle[3]]);
                if (curr_nod[0][1]) {
					if (d) {
                        if (g) { //write_action finished right.
							if (randomElection([1, 0], [1 - p_of_local_failure * current_needle[3], p_of_local_failure * current_needle[3]])) {
                            curr_nod[0][2][key_of_needle] = t //current_needle, put new Leofs objeckt, or fresh information with same key value.
			                curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
							curr_nod[0][5] = Math.max(curr_nod[0][5], gtw_curr_nod[0][2]) + use_time_for_performance_local_action_with_one_cond_unit_of_data * current_needle[4];//time for performance local action.
							total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion,curr_nod[0][5]);	
							change_node_status.push([curr_nod[0][0], 1, t]);//succesful write action for node.
                            node_status[2][curr_nod[0][0]].push(key_of_needle + '_' + t);
                            total_count_of_data  = total_count_of_data + current_needle[1]; //fresh information
			                total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
							if(node_status[1][key_of_needle]) {
								node_status[1][key_of_needle].push([curr_nod[0][0], 0, t]);
								}
							r = r + 1; 
							} else {
								r = r + 1;
								if(node_status[1][key_of_needle]) {
								node_status[1][key_of_needle].push([curr_nod[0][0], 0, t]);
								}
								curr_nod[0][2][key_of_needle] = t //current_needle, put new Leofs objeckt
								curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
								c = c - 1;
								total_count_of_failures = total_count_of_failures + 1; //fresh information.
								total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
								total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
								total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
								count_of_local_failure = count_of_local_failure +1;
								}
			            } else {
							r = r + 1;
			                curr_nod[0][1] = 0; // set 0 for the work_status node_j.
							if(node_status[1][key_of_needle]) {
							node_status[1][key_of_needle].push([curr_nod[0][0], 0, t]);
							}
                            curr_nod[0][2][key_of_needle] = t //current_needle, put new Leofs objeckt
			                curr_nod[0][3] = curr_nod[0][3] + current_needle[1]; //fresh information.
			                c = c - 1;
			                total_count_of_failures = total_count_of_failures + 1; //fresh information.
                            count_of_failures_for_write_action = count_of_failures_for_write_action + 1;
                            total_used_resource = total_used_resource + (use_of_resource_by_write_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_write_action = total_use_of_resource_by_write_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                        }
                    } else {
		                c = c - 1;
			            total_count_of_failures = total_count_of_failures + 1; //fresh information.
                        count_of_failures_for_send_action = count_of_failures_for_send_action + 1;
				        total_used_resource = total_used_resource + use_of_resource_by_send_action * current_needle[1];
                        total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                    }
                } else {
		            c = c - 1;
                }  
    } else {
	     c = c - 1;
		 }
	}
            for (k = 0; k < curr_ar.length; k++) {
        storage_nodes.push(curr_ar[k]);
            }
              if (c < w_value ) {
                count_of_write_failures = count_of_write_failures + 1;				 // loss of availability.
				if (r) {
				node_status[4][key_of_needle] = t; 
				}
            } else {
				node_status[1][key_of_needle] = change_node_status;
                count_of_right_write_action = count_of_right_write_action + 1;
                node_status[0][key_of_needle] = t;
               }             
			
        }
        //else {
        var u1;
        if (current_action === read_action) {
            if (w) {
           u1 = list_of_entering_keys.length;
            key_of_needle = randomElection(list_of_entering_keys,  uniformDistrOf_n_Elem(u));
			
            current_needle = obj_current[key_of_needle];
           
            var b1, c1;  //counter,shows count of nodes,which must contain new Raik object
            c1 = 0;
			           
            var node_status_read;
            node_status_read = [];    
            var curr_nod1, gtw_curr_nod1, g1, d1, t0, j1, q;
				
                q = 0;
                t0 = 0;
                j1 = 0;
                if ((node_status[1][key_of_needle] != []) && (node_status[1][key_of_needle] != undefined)) {
				b1 = node_status[1][key_of_needle].length;
            while (j1 < b1) {
                j1 = j1 + 1;
                 
                curr_nod1 = randomElectAndDeleteItem(node_status[1][key_of_needle]);
                node_status_read.push(curr_nod1[0]);
				if (curr_nod1[0]) {
				                
                g1 = randomElection([1, 0], [1 - p_of_read_action * current_needle[3], p_of_read_action * current_needle[3]]);
                d1 = randomElection([1, 0], [1 - p_of_send_action * current_needle[3], p_of_send_action * current_needle[3]]);
            
                if (curr_nod1[0][1]) {
                    if (d1) {
                        if (g1) { //read_action finished right.
						    if(curr_nod1[0][2] > t0) {
							t0 = curr_nod1[0][2];
							}
							for (n = 0; n < storage_nodes.length; n++) {
							if (storage_nodes[n][0] == curr_nod1[0][0]) {
                            storage_nodes[n][5] = Math.max(storage_nodes[n][5], gtw_curr_nod[0][2], t) +  use_time_for_performance_local_action_with_one_cond_unit_of_data * current_needle[4];//time for performance local action.
							max_lag_of_performance_of_read_request = Math.max(max_lag_of_performance_of_read_request, storage_nodes[n][5] - t);
							total_time_of_finish_imitatiion = Math.max(total_time_of_finish_imitatiion,storage_nodes[n][5]);
							}
							}
			                total_used_resource = total_used_resource + (use_of_resource_by_read_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_read_action = total_use_of_resource_by_read_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
							c1 = c1 +1;
			            } else {

			                total_count_of_failures = total_count_of_failures + 1; //fresh information.
                            count_of_failures_for_read_action = count_of_failures_for_read_action + 1;
                            total_used_resource = total_used_resource + (use_of_resource_by_read_action + use_of_resource_by_send_action) * current_needle[1]; //fresh information.
                            total_use_of_resource_by_read_action = total_use_of_resource_by_read_action + current_needle[1];
                            total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
                        }
                    } else {
		                //c1 = c1 - 1;
                       
			            total_count_of_failures = total_count_of_failures + 1; //fresh information.
                        count_of_failures_for_send_action = count_of_failures_for_send_action + 1;
				        total_used_resource = total_used_resource + use_of_resource_by_send_action * current_needle[1];
                        total_use_of_resource_by_send_action = total_use_of_resource_by_send_action + current_needle[1];
						
                    }
                }
				} else {
						q = q + 1;
						}
		}			
   } else {
				count_of_wrong_read_request = count_of_wrong_read_request + 1;
				}				
      for(i = 0; i < node_status_read.length; i++) {
          if (node_status_read[i] != undefined) {                 
       node_status[1][key_of_needle].push(node_status_read[i]);
	   }
     }
	 node_status_read = [];
		if (q > 2) {
					count_of_wrong_read_request = count_of_wrong_read_request + 1;
					}
         if (c1 < r_value ) {
                
                count_of_read_failures = count_of_read_failures + 1;// loss of availability.
            } else {
                count_of_right_read_action = count_of_right_read_action + 1;
                if (node_status[3][key_of_needle] > t0) {
				count_of_read_lags = count_of_read_lags +1; //cases of outdate information.
				}
				}
}				
}				
        }  
        }    
	total_used_resource = total_used_resource + total_use_of_resource_by_repair_action;
    /*console.log('count_of_right_read_action - ' + count_of_right_read_action,
			'count_of_right_write_action - ' + count_of_right_write_action,
			'count_of_failures_for_send_action - ' + count_of_failures_for_send_action, 'count_of_failures_for_write_action - ' + count_of_failures_for_write_action, 'count_of_failures_for_read_action - ' + count_of_failures_for_read_action,
			'count_of_local_failure - ' + count_of_local_failure,
			'count_of_wrong_read_request - ' + count_of_wrong_read_request,
			'total_use_of_resource_by_write_action - ' + Math.floor(total_use_of_resource_by_write_action), 'total_use_of_resource_by_read_action - ' + Math.floor(total_use_of_resource_by_read_action), 'total_use_of_resource_by_send_action - ' + Math.floor(total_use_of_resource_by_send_action),
			'total_time_of_finish_imitatiion - ' + total_time_of_finish_imitatiion,
    		'total_use_of_resource_by_repair_action - ' + Math.floor(total_use_of_resource_by_repair_action));

//output of algorithm:

    alert(["total_count_of_data - " + Math.floor(total_count_of_data), // in all servers,
	    "total_used_resource - " + Math.floor(total_used_resource),
	    "total_count_of_failures - " + total_count_of_failures,//net's  partitions,  failures of  equipment.
	    "count_of_read_lags(outdated information) - " + count_of_read_lags,//cases of outdate information.
	    "count_of_read_failures (decreasing of the availability) - " + count_of_read_failures,// failures to   requests  for getting data.
	    "count_of_write_failures (decreasing of the availability) - " + count_of_write_failures,
		"max_lag_of_performance_of_read_request - " + max_lag_of_performance_of_read_request.toFixed(3),
		"max_lag_of_performance_for_gateway_nodes - " + max_lag_of_performance_for_gateway_nodes.toFixed(3),
	    "count_of_read//write_actions - " + count_of_iterations_for_algorithm * level_of_intensivity_of_requests]);
     console.log(node_status, 'con_gp_f',total_count_of_data / total_used_resource , (count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests), ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests) - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests), w, v,storage_nodes);
   
return [(total_count_of_data / total_used_resource).toFixed(3) + '  ', ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)).toFixed(3) + '  ',  ((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)).toFixed(3) + '  ', total_count_of_data.toPrecision(4) + '  ', total_used_resource.toPrecision(4) + '  ',count_of_read_lags, count_of_read_failures, count_of_write_failures, Math.round(max_lag_of_performance_of_read_request), count_of_iterations_for_algorithm * level_of_intensivity_of_requests, w]*/ 
return [(total_count_of_data / total_used_resource).toFixed(3), (((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - (count_of_read_failures +  count_of_write_failures)) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)) * 100).toFixed(3), (((count_of_iterations_for_algorithm * level_of_intensivity_of_requests - count_of_read_lags) / (count_of_iterations_for_algorithm * level_of_intensivity_of_requests)) * 100).toFixed(3), total_count_of_data.toPrecision(4), total_used_resource.toPrecision(4), total_count_of_failures, count_of_read_lags, count_of_read_failures, count_of_write_failures, max_lag_of_performance_of_read_request, max_lag_of_performance_for_gateway_nodes, count_of_iterations_for_algorithm * level_of_intensivity_of_requests, w]    
}		  
 		  
 